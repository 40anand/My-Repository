package com.example.anand.olxtechathon;

import android.content.Context;
import android.widget.ArrayAdapter;

/**
 * Created by Anand on 9/26/2015.
 */
public class AutoCompleteTextAdapter extends ArrayAdapter<String> {
    public AutoCompleteTextAdapter(Context context, int resource, String[] objects) {
        super(context, resource, objects);
    }
}
