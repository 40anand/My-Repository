package com.example.anand.youtubechannel.control.core;

import android.util.Log;

import com.example.anand.youtubechannel.control.ui.VideoItem;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class VideoListParser {

    private static final String TAG = VideoListParser.class.getSimpleName();

    private static final String JSON_ARRAY_ITEMS = "items";
    private static final String JSON_OBJECT_SNIPPET = "snippet";
    private static final String JSON_OBJECT_ID = "id";
    private static final String JSON_OBJECT_THUMBNAILS = "thumbnails";
    //private static final String JSON_OBJECT_THUMBNAILS_DEFAULT = "default";
    private static final String JSON_OBJECT_THUMBNAILS_HIGH = "high";
    private static final String JSON_STRING_VIDEO_ID = "videoId";
    private static final String JSON_STRING_TITLE = "title";
    private static final String JSON_STRING_THUMBNAILS_DEFAULT_URL = "url";
    private static final String JSON_STRING_NEXT_PAGE_TOKEN = "nextPageToken";

    public static ArrayList<VideoItem> getVideoList(JSONObject jsonObject) {

        ArrayList<VideoItem> videoItems = null;
        Log.d(TAG, jsonObject.toString());
        try {
            videoItems = new ArrayList<>();
            JSONArray jsonArray = jsonObject.getJSONArray(JSON_ARRAY_ITEMS);
            int length = jsonArray.length();
            for (int i = 0; i < length; i++) {
                JSONObject currentJsonObject = jsonArray.getJSONObject(i);
                JSONObject currentSnippetObject = currentJsonObject.getJSONObject(JSON_OBJECT_SNIPPET);

                String videoId;
                try {
                    videoId = currentJsonObject.getJSONObject(JSON_OBJECT_ID).getString(JSON_STRING_VIDEO_ID);
                } catch (JSONException e) {
                    e.printStackTrace();
                    continue;
                }
                String title = currentSnippetObject.getString(JSON_STRING_TITLE);
                String thumbUrl = currentSnippetObject.getJSONObject(JSON_OBJECT_THUMBNAILS).
                        getJSONObject(JSON_OBJECT_THUMBNAILS_HIGH).getString(JSON_STRING_THUMBNAILS_DEFAULT_URL);

                VideoItem videoItem = new VideoItem();
                videoItem.setVideoId(videoId);
                videoItem.setTitle(title);
                videoItem.setThumbUrl(thumbUrl);
                videoItems.add(videoItem);
            }
            return videoItems;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return videoItems;
    }

    public static ArrayList<VideoItem> loadNextPageVideoList(JSONObject jsonObject, ArrayList<VideoItem> videoItems) {
        try {
            JSONArray jsonArray = jsonObject.getJSONArray(JSON_ARRAY_ITEMS);
            int length = jsonArray.length();
            for (int i = 0; i < length; i++) {
                JSONObject currentJsonObject = jsonArray.getJSONObject(i);
                JSONObject currentSnippetObject = currentJsonObject.getJSONObject(JSON_OBJECT_SNIPPET);

                String videoId;
                try {
                    videoId = currentJsonObject.getJSONObject(JSON_OBJECT_ID).getString(JSON_STRING_VIDEO_ID);
                } catch (JSONException e) {
                    e.printStackTrace();
                    continue;
                }
                String title = currentSnippetObject.getString(JSON_STRING_TITLE);
                String thumbUrl = currentSnippetObject.getJSONObject(JSON_OBJECT_THUMBNAILS).
                        getJSONObject(JSON_OBJECT_THUMBNAILS_HIGH).getString(JSON_STRING_THUMBNAILS_DEFAULT_URL);

                VideoItem videoItem = new VideoItem();
                videoItem.setVideoId(videoId);
                videoItem.setTitle(title);
                videoItem.setThumbUrl(thumbUrl);
                videoItems.add(videoItem);
            }
            return videoItems;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return videoItems;
    }

    public static String getNextPageToken(JSONObject jsonObject) {
        try {
            return jsonObject.getString(JSON_STRING_NEXT_PAGE_TOKEN);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

}
