package com.example.anand.youtubechannel.control.ui;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.anand.youtubechannel.R;
import com.example.anand.youtubechannel.control.core.ListInterface;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class VideoListAdapter extends RecyclerView.Adapter<VideoViewHolder> {

    private ArrayList<VideoItem> mVideoItems;
    private Context mContext;
    private LayoutInflater mInflater;
    private ListInterface mListInterface;
    private View.OnClickListener mClickListener;
    private View mFooterView;

    public VideoListAdapter(Context context, ListInterface listener, View.OnClickListener clickListener) {
        mContext = context;
        mListInterface = listener;
        mClickListener = clickListener;
        mInflater = LayoutInflater.from(mContext);
    }

    public void destroy() {
        mContext = null;
        mInflater = null;
        mFooterView = null;
    }

    public void setVideoItems(ArrayList<VideoItem> videoItems) {
        mVideoItems = videoItems;
    }

    @Override
    public VideoViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.list_item_video, parent, false);
        itemView.setOnClickListener(mClickListener);
        return (new VideoViewHolder(itemView));
    }

    @Override
    public void onBindViewHolder(VideoViewHolder holder, int position) {
        holder.shareButton.setTag(position);
        holder.shareButton.setOnClickListener(mClickListener);

        holder.itemView.setTag(position);
        holder.itemView.setOnClickListener(mClickListener);

        VideoItem videoItem = mVideoItems.get(position);
        holder.title.setText(videoItem.getTitle());
        Picasso.with(mContext).load(videoItem.getThumbUrl()).placeholder(R.drawable.default_youtube_image)
                .into(holder.thumb);

        if (position == getItemCount() - 1) {
            mListInterface.loadMoreVideos();
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        if (mVideoItems != null) {
            return mVideoItems.size();
        }
        return 0;
    }

    public void loadNextPageSuccess() {
        notifyDataSetChanged();
    }

    public void loadNextPageFailure() {
        TextView noVideoText = (TextView) mFooterView.findViewById(R.id.load_more_no_video_text);
        ProgressBar noVideoProgressBar = (ProgressBar) mFooterView.findViewById(R.id.load_more_no_video_loading);
        noVideoText.setVisibility(View.VISIBLE);
        noVideoProgressBar.setVisibility(View.GONE);
    }
}
