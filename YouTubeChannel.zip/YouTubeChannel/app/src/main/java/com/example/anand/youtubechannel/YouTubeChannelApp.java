package com.example.anand.youtubechannel;

import android.app.Application;

public class YouTubeChannelApp extends Application {

    private static YouTubeChannelApp mInstance;

    @Override
    public void onCreate() {
        mInstance = this;
        super.onCreate();
    }

    public static YouTubeChannelApp getInstance() {
        return mInstance;
    }
}
