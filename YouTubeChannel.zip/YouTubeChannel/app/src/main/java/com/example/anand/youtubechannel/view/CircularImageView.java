package com.example.anand.youtubechannel.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Outline;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.ImageView;

public class CircularImageView extends ImageView {

    public CircularImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.setOutlineProvider(new CircularImageViewOutlineProvider());
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.setClipToOutline(true);
    }

    static class CircularImageViewOutlineProvider extends ViewOutlineProvider {

        @Override
        public void getOutline(View view, Outline outline) {
            Rect rect = new Rect();
            view.getDrawingRect(rect);
            outline.setOval(rect);
        }
    }
}
