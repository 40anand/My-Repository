package com.example.anand.youtubechannel.control.ui;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.example.anand.youtubechannel.R;

public class VideoViewHolder extends RecyclerView.ViewHolder {
    TextView title;
    ImageView thumb;
    ImageView shareButton;

    public VideoViewHolder(View itemView) {
        super(itemView);
        title = (TextView) itemView.findViewById(R.id.video_title);
        thumb = (ImageView) itemView.findViewById(R.id.video_thumb);
        shareButton = (ImageView) itemView.findViewById(R.id.video_item_share_button);
    }
}
