package com.example.anand.youtubechannel.control.ui;

import java.util.ArrayList;
import org.json.JSONObject;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.anand.youtubechannel.R;
import com.example.anand.youtubechannel.control.core.CommonUtils;
import com.example.anand.youtubechannel.control.core.ListInterface;
import com.example.anand.youtubechannel.control.core.NetworkRequestHelper;
import com.example.anand.youtubechannel.control.core.ShareVia;
import com.example.anand.youtubechannel.control.core.VideoListParser;

public class VideoListActivity extends Activity implements View.OnClickListener, ListInterface {

    private static final String FIRST_PAGE_REQUEST = "first_request";
    private static final String NEXT_PAGE_REQUEST = "next_page_request";

    private ArrayList<VideoItem> mVideoItems;
    private RecyclerView mVideoListView;
    private RecyclerView.LayoutManager mLayoutManager;

    private VideoListAdapter mVideoListAdapter;

    private String nextPageToken;

    private ProgressDialog mProgressDialog;

    @Override
    public void loadMoreVideos() {
        if (nextPageToken != null) {
            JSONObject jsonObject = new JSONObject();
            JsonObjectRequest jsonObjectRequest =
                    new JsonObjectRequest(Request.Method.GET, CommonUtils.getUrlForNextPage(nextPageToken), jsonObject,
                                          nextPageLoadListener, nextPageErrorListener);
            jsonObjectRequest.setTag(NEXT_PAGE_REQUEST);
            NetworkRequestHelper.getInstance().addJsonObjectRequest(jsonObjectRequest);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_video_list);
        mVideoListView = (RecyclerView) findViewById(R.id.main_video_list);

        mLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        mVideoListView.setLayoutManager(mLayoutManager);

        mVideoListAdapter = new VideoListAdapter(this, this, this);
        mVideoListView.setAdapter(mVideoListAdapter);
        mVideoListView.setHasFixedSize(false);

        mVideoItems = new ArrayList<>();
        loadFirstPage();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void loadFirstPage() {
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setMessage("Retrieving Video List");
        mProgressDialog.show();

        JSONObject jsonObject = new JSONObject();
        JsonObjectRequest jsonObjectRequest =
                new JsonObjectRequest(Request.Method.GET, CommonUtils.CHANNEL_VIDEO_URL, jsonObject,
                                      firstPageLoadListener, firstPageErrorListener);
        jsonObjectRequest.setTag(FIRST_PAGE_REQUEST);
        NetworkRequestHelper.getInstance().addJsonObjectRequest(jsonObjectRequest);
    }

    private Response.Listener<JSONObject> firstPageLoadListener = new Response.Listener<JSONObject>() {
        @Override
        public void onResponse(JSONObject jsonObject) {
            mVideoItems = VideoListParser.getVideoList(jsonObject);
            nextPageToken = VideoListParser.getNextPageToken(jsonObject);
            mVideoListAdapter.setVideoItems(mVideoItems);
            mVideoListAdapter.notifyDataSetChanged();

            if (mProgressDialog != null && mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
        }
    };

    private Response.ErrorListener firstPageErrorListener = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError volleyError) {
            if (mProgressDialog != null && mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
            Toast.makeText(VideoListActivity.this, "An Error Occurred while retrieving Video List", Toast.LENGTH_SHORT)
                    .show();
            volleyError.printStackTrace();
        }
    };

    private Response.Listener<JSONObject> nextPageLoadListener = new Response.Listener<JSONObject>() {
        @Override
        public void onResponse(JSONObject jsonObject) {
            mVideoItems = VideoListParser.loadNextPageVideoList(jsonObject, mVideoItems);
            nextPageToken = VideoListParser.getNextPageToken(jsonObject);
            mVideoListAdapter.setVideoItems(mVideoItems);
            mVideoListAdapter.loadNextPageSuccess();
        }
    };

    private Response.ErrorListener nextPageErrorListener = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError volleyError) {
            mVideoListAdapter.loadNextPageFailure();
            volleyError.printStackTrace();
        }
    };

    @Override
    protected void onDestroy() {
        if (mVideoListAdapter != null) {
            mVideoListAdapter.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onClick(View view) {
        int position;
        VideoItem item;
        switch (view.getId()) {
        case R.id.video_item:
            position = (int) view.getTag();
            item = mVideoItems.get(position);
            if (item.getVideoId() == null) {
                Toast.makeText(this, " Video id is Null", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(this, PlayVideoActivity.class);
            intent.putExtra(CommonUtils.VIDEO_ID, item.getVideoId());
            intent.putExtra(CommonUtils.TITLE, item.getTitle());
            startActivity(intent);
            break;
        case R.id.video_item_share_button:
            position = (int) view.getTag();
            item = mVideoItems.get(position);
            ShareVia.shareVideo(VideoListActivity.this, item.getVideoId());
            break;
        }

    }
}
