package com.example.anand.youtubechannel.control.core;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.Volley;
import com.example.anand.youtubechannel.YouTubeChannelApp;

public class NetworkRequestHelper {

    private static final int CACHE_SIZE = 1024 * 1024;

    private static NetworkRequestHelper mInstance;
    private RequestQueue mRequestQueue;
    private Cache mCache;
    private Network mNetwork;

    private NetworkRequestHelper() {
        if (mCache == null) {
            mCache = new DiskBasedCache(YouTubeChannelApp.getInstance().getCacheDir(), CACHE_SIZE);
        }
        if (mNetwork == null) {
            mNetwork = new BasicNetwork(new HurlStack());
        }
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(YouTubeChannelApp.getInstance());
        }

    }

    public static synchronized NetworkRequestHelper getInstance() {
        if (mInstance == null) {
            mInstance = new NetworkRequestHelper();
        }
        return mInstance;
    }

    public void addJsonObjectRequest(Request request) {
        mRequestQueue.add(request);
    }

}