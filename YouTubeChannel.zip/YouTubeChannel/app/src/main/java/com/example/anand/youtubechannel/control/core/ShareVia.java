package com.example.anand.youtubechannel.control.core;

import android.content.Context;
import android.content.Intent;

public class ShareVia {
    public static void shareVideo(Context context, String videoId) {
        try {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT, "Title Of The Post");
            intent.putExtra(Intent.EXTRA_TEXT, CommonUtils.YOUTUBE_VIDEO_VIEW_URL + videoId);

            context.startActivity(Intent.createChooser(intent, "Share Video!"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
