package com.example.anand.youtubechannel.control.core;

public class CommonUtils {

    public static final String API_KEY = "AIzaSyB1AljpOL_urnXV5hFD4mIeWBWsnfsOrBU";
    public static final String CHANNEL_ID = "UCkqpGeRn9P6-W2vK2qopo0w";
    public final static String CHANNEL_VIDEO_URL =
            "https://www.googleapis.com/youtube/v3/search?key=" + API_KEY
                    + "&channelId=" + CHANNEL_ID
                    + "&part=snippet,id&order=date&maxResults=20";

    public static final String YOUTUBE_VIDEO_VIEW_URL = "https://www.youtube.com/watch?v=";

    public static final String VIDEO_ID = "video_id";
    public static final String TITLE = "title";

    public static String getUrlForNextPage(String nextPageToken) {
        return CHANNEL_VIDEO_URL + "&pageToken=" + nextPageToken;
    }

}
