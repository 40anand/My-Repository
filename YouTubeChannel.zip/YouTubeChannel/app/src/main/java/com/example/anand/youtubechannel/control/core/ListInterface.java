package com.example.anand.youtubechannel.control.core;

/**
 * Created by Anand on 11-07-2015.
 */
public interface ListInterface {
    void loadMoreVideos();
}
