package com.example.anand.youtubechannel.control.ui;

import android.app.ActionBar;
import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.app.FragmentManager;
import android.view.View;
import android.widget.ImageButton;

import com.example.anand.youtubechannel.R;
import com.example.anand.youtubechannel.control.core.CommonUtils;
import com.example.anand.youtubechannel.control.core.ShareVia;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerFragment;


public class PlayVideoActivity extends Activity implements YouTubePlayer.OnInitializedListener, View.OnClickListener {

    private YouTubePlayerFragment mYouTubePlayerFragment;
    private String videoId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_video);

        FragmentManager fm = getFragmentManager();
        mYouTubePlayerFragment = (YouTubePlayerFragment) fm.findFragmentById(R.id.youtube_player_fragment);
        ImageButton shareButton = (ImageButton) findViewById(R.id.share_button);
        shareButton.setOnClickListener(this);
        videoId = getIntent().getStringExtra(CommonUtils.VIDEO_ID);

        ActionBar actionBar = getActionBar();
        String title = getIntent().getStringExtra(CommonUtils.TITLE);
        if (actionBar != null && title != null) {
            actionBar.setTitle(title);
        }
        mYouTubePlayerFragment.initialize(CommonUtils.API_KEY, this);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mYouTubePlayerFragment.onConfigurationChanged(newConfig);
    }

    @Override
    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean start) {
        youTubePlayer.setPlayerStateChangeListener(playerStateChangeListener);
        youTubePlayer.setPlaybackEventListener(playbackEventListener);

        if (!start) {
            youTubePlayer.cueVideo(videoId);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void onInitializationFailure(YouTubePlayer.Provider provider,
                                        YouTubeInitializationResult youTubeInitializationResult) {

    }

    private YouTubePlayer.PlaybackEventListener playbackEventListener = new YouTubePlayer.PlaybackEventListener() {

        @Override
        public void onBuffering(boolean arg0) {
        }

        @Override
        public void onPaused() {
        }

        @Override
        public void onPlaying() {
        }

        @Override
        public void onSeekTo(int arg0) {
        }

        @Override
        public void onStopped() {
        }

    };

    private YouTubePlayer.PlayerStateChangeListener playerStateChangeListener =
            new YouTubePlayer.PlayerStateChangeListener() {

                @Override
                public void onAdStarted() {
                }

                @Override
                public void onError(YouTubePlayer.ErrorReason arg0) {
                }

                @Override
                public void onLoaded(String arg0) {
                }

                @Override
                public void onLoading() {
                }

                @Override
                public void onVideoEnded() {
                }

                @Override
                public void onVideoStarted() {
                }
            };

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
        case R.id.share_button:
            ShareVia.shareVideo(this, videoId);
            break;
        }
    }
}
