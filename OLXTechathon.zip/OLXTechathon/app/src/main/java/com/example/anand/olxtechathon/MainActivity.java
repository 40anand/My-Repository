package com.example.anand.olxtechathon;

import java.io.File;
import java.lang.ref.WeakReference;
import java.util.Date;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends Activity implements View.OnClickListener {

    private ImageView mProductPic;
    private TextView mPurchaseDate;
    private Button mPostButton;
    private EditText mPrice;
    private AutoCompleteTextView mProductChooser;
    private AutoCompleteTextView mProductModelChooser;
    private AutoCompleteTextView mProductSubModelChooser;

    private Button mHistoryButton;

    private String mProductImagePath;

    private static final int REQUEST_TAKE_IMAGE = 1;
    private static final int MSG_SET_PRODUCT_IMAGE = 101;

    private InnerHandler mHandler;

    private WeakReference<Bitmap> bitmapWeakReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mProductPic = (ImageView) findViewById(R.id.product_image);
        mProductPic.setOnClickListener(this);
        mPostButton = (Button) findViewById(R.id.post_button);
        mPostButton.setOnClickListener(this);
        mPrice = (EditText) findViewById(R.id.price);
        mProductChooser = (AutoCompleteTextView) findViewById(R.id.product);
        mProductModelChooser = (AutoCompleteTextView) findViewById(R.id.product_model);
        mProductSubModelChooser = (AutoCompleteTextView) findViewById(R.id.product_sub_model);
        mHistoryButton = (Button) findViewById(R.id.post_history);
        mHistoryButton.setOnClickListener(this);

        mHandler = new InnerHandler();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
        case R.id.product_image:
            takeProductImage();
            break;
        case R.id.post_button:
            break;
        case R.id.post_history:
            break;

        }
    }

    private void takeProductImage() {
        File olxDataFolder = new File(Common.THUMBNAIL_DIRECTORY_PATH);
        if (!olxDataFolder.exists()) {
            if (!olxDataFolder.mkdir()) {
                return;
            }
        }
        String thumbPath = String.valueOf(System.currentTimeMillis()) + Common.JPEG_EXTENSION;
        File thumbFile = new File(olxDataFolder, thumbPath);
        Uri outputFileUri = Uri.fromFile(thumbFile);
        mProductImagePath = outputFileUri.toString();
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
        startActivityForResult(cameraIntent, REQUEST_TAKE_IMAGE);
    }

    private class InnerHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
            case MSG_SET_PRODUCT_IMAGE:
                mProductPic.setImageBitmap(bitmapWeakReference.get());
            }
            super.handleMessage(msg);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_TAKE_IMAGE) {
            if (resultCode == RESULT_OK) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Bitmap bmp = BitmapFactory.decodeFile(mProductImagePath.substring(8));
                        bmp = Bitmap.createScaledBitmap(bmp, 400, 400, true);
                        bitmapWeakReference = new WeakReference<>(bmp);
                        mHandler.sendEmptyMessage(MSG_SET_PRODUCT_IMAGE);
                    }
                }).start();

            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
