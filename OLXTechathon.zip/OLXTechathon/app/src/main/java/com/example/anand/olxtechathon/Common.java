package com.example.anand.olxtechathon;

import android.os.Environment;

public class Common {
    public static final String SLASH = "/";
    public static final String THUMBNAIL_DIRECTORY_NAME = "OLX";
    public static final String THUMBNAIL_DIRECTORY_PATH =
            Environment.getExternalStorageDirectory().getAbsolutePath() + SLASH + THUMBNAIL_DIRECTORY_NAME + SLASH;

    public static final String JPEG_EXTENSION = ".jpg";

}
